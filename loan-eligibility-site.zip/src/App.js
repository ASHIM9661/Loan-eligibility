import React from "react";
import LoanEligibility from "./LoanEligibility";

function App() {
  return <LoanEligibility />;
}

export default App;